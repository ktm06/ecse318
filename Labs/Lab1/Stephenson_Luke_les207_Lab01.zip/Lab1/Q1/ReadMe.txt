Question 1 part C:
Using ModelSim, can you verify that the model in a) and b) are equivalent? (Explain)

No. ModelSim can only prove that for any given input the two models are equivilant.
To prove they are exactly the same you would have to test every single set of inputs which gets unfeasable at scale.
